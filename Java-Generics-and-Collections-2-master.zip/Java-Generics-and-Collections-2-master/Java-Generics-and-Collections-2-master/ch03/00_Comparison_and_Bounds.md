《《《 [返回首页](../README.md)       <br/>
《《《 [上一节](../ch02/08_Restrictions_on_Wildcards.md)

### 比较和界限

现在我们已经掌握了基本知识，让我们看看泛型的一些更高级的用法。本章介绍用于支持元素比较的接口 `Comparable <T>` 和 `Comparator <T>`。 例如，如果要查找
集合的最大元素或对列表进行排序，这些接口很有用。 一路上，我们将介绍类型变量的界限，这是泛型的一个重要特性，与 `Comparable <T>` 界面结合使用特别有用。

《《《 [下一节](01_Comparable.md)      <br/>
《《《 [返回首页](../README.md)
