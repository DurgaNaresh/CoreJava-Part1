《《《 [返回首页](../README.md)       <br/>
《《《 [上一节](../ch03/08_Covariant_Overriding.md)

## 声明

本章讨论如何声明一个通用类。 它描述了构造函数，静态成员和嵌套类，它填补了擦除工作的一些细节。

《《《 [下一节](01_Constructors.md)      <br/>
《《《 [返回首页](../README.md)
