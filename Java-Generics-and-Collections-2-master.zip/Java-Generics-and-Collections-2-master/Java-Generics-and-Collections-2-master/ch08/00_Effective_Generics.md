《《《 [返回首页](../README.md)       <br/>
《《《 [上一节](../ch07/06_Reflecting_Generic_Types.md)

### 有效的泛型

本章包含如何在实际编码中有效使用泛型的建议。 我们考虑检查集合，安全问题，专用类和二进制兼容性。 本节的标题是对 `Joshua Bloch` 的着作 
`Effective Java(Addison-Wesley)` 的致敬。

《《《 [下一节](01_Take_Care_when_Callin_Legacy_Code.md)      <br/>
《《《 [返回首页](../README.md)
