《《《 [返回首页](../README.md)       <br/>
《《《 [上一节](../ch08/04_Maintain_Binary_Compatibility.md)

### 设计模式

本章回顾了五种着名的设计模式 - 访问者，解释器，函数，策略和主题观察者，并展示了他们如何利用泛型。函数模式概括了比较器接口的思想。 其他四种模式在
`Gamma`，`Helm`，`Johnson` 和 `Vlissides`（`Addison-Wesley`）的开创性设计模式中描述。

《《《 [下一节](01_Visitor.md)      <br/>
《《《 [返回首页](../README.md)
