《《《 [返回首页](../README.md)       <br/>
《《《 [上一节](../ch10/01_The_Main_Interfaces_of_the_Java.md)

### 初步措施

在本章中，在深入讨论集合本身的细节之前，我们将花时间讨论框架的基本概念。

《《《 [下一节](01_Iterable_and_Iterators.md)      <br/>
《《《 [返回首页](../README.md)
