# 第十一章\(初步措施\)

《《《 [返回首页](../../)  
《《《 [上一节](../di-shi-zhang-ji-he/10.1-java-ji-he-kuang-jia-de-zhu-yao-jie-kou.md)

## 初步措施

在本章中，在深入讨论集合本身的细节之前，我们将花时间讨论框架的基本概念。

《《《 [下一节](11.1-ke-die-dai-he-die-dai-qi.md)  
《《《 [返回首页](../../)

