# 第一部分：泛型

《《《 [返回首页](../)   
 《《《 [上一节](https://github.com/zerotoneorg/Java-Generics-and-Collections/tree/e41f1e9a8eb376f2de33abd6022ce3b2989ba771/Preface.md)

## 第一章\(简介\)

`Java` 最新版本中现在对泛型和集合与许多其他新功能有良好的支持，包括装箱和拆箱，新的循环形式，以及接受可变数量参数的函数。我们从一个例子开始说明了这些。 我们将会看到，将它们相结合是协同的：整数求和。

因此作为我们的座右铭，让我们做一些简单求和：把三个数字一个列表并将它们加在一起。 下面是如何在 `Java` 中使用泛型：

```java
   List<Integer> ints = Arrays.asList(1,2,3);
   int s = 0;
   for (int n : ints) {
     s += n;
   }
   assert s == 6;
```

不需要太多的解释你就可以读懂代码，但是让我们来看看关键特征。接口列表和类数组是集合框架的一部分（都可以在 `java.util` 包中找到）。类型 `List` 现在是通用的；你写 `List<E>` 以指示具有类型 `E` 的元素的列表。这里我们写 `List<Integer>` 指出列表的元素属于 `Integer` 类，即包装类对应于基本类型`int`。装箱和拆箱操作，用于转换从原始类型到包装类，自动插入。静态方法 `asList` 可以使用任意数量的参数，将它们放入一个数组中，然后返回一个由数组支持的新列表。新的循环形式，`foreach` 被用来绑定一个变量依次到列表的每个元素，循环体将这些添加到总和中。该断言语句（在 `Java1.4` 中引入）用于检查总和是否正确。当启用断言时，如果条件不成立，则会引发错误。

下面是在泛型之前 `Java` 中相同作用的代码：

```java
   List ints = Arrays.asList( new Integer[] {
     new Integer(1), new Integer(2), new Integer(3)
   } );
   int s = 0;
   for (Iterator it = ints.iterator(); it.hasNext(); ) {
     int n = ((Integer)it.next()).intValue();
     s += n;
   }
   assert s == 6;
```

阅读这段代码并不是那么容易。 没有泛型，就没有办法指出类型声明你打算在列表中存储什么样的元素，所以而不是写 `List<Integer>`，你写 `List`。 现在是编辑器而不是编译器谁负责记住列表元素的类型，所以你必须写下从列表中提取元素时将其转换为（整数）。 没有装箱和拆箱，你必须显式地分配属于包装类 `Integer` 的每个对象并使用 `intValue` 方法提取相应的基元 `int`。 没有功能接受可变数量的参数，您必须显式地分配一个数组传递给`asList`方法。 没有新的循环形式，你必须显式声明一个迭代器，并通过列表推进。

顺便说一句，下面是如何在泛型之前用 `Java` 中的数组做同样的事情：

```java
   int[] ints = new int[] { 1,2,3 };
   int s = 0;
   for (int i = 0; i < ints.length; i++) {
     s += ints[i];
   }
   assert s == 6;
```

这比使用泛型和集合的相应代码略长，可以说是不太可读，而且肯定不够灵活。 集合让你轻松增大或缩小集合的大小，或在切换到适当的不同的表示形式时，如链表或散列表或有序树。`java` 的泛型，装箱和拆箱，`foreach` 循环和 `Java` 中的可变参数标志着第一次使用集合与使用数组一样简单，甚至可能更简单。

现在我们来看一下这些功能的更多细节。

《《《 [下一节](https://github.com/zerotoneorg/Java-Generics-and-Collections/tree/e41f1e9a8eb376f2de33abd6022ce3b2989ba771/ch01/01_Generics.md)   
 《《《 [返回首页](../)

