# 第八章\(有效的泛型\)

《《《 [返回首页](../../)  
《《《 [上一节](../di-qi-zhang-fan-she/7.6-fan-si-fan-xing-lei-xing.md)

## 有效的泛型

本章包含如何在实际编码中有效使用泛型的建议。 我们考虑检查集合，安全问题，专用类和二进制兼容性。 本节的标题是对 `Joshua Bloch` 的着作 `Effective Java(Addison-Wesley)` 的致敬。

《《《 [下一节](8.1-tiao-yong-yi-liu-dai-ma-shi-yao-xiao-xin.md)  
《《《 [返回首页](../../)

