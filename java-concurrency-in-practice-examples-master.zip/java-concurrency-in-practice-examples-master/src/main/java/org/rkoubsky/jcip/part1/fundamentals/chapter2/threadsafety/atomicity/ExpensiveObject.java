package org.rkoubsky.jcip.part1.fundamentals.chapter2.threadsafety.atomicity;

/**
 * This is an expensive object
 */
public class ExpensiveObject {
}
