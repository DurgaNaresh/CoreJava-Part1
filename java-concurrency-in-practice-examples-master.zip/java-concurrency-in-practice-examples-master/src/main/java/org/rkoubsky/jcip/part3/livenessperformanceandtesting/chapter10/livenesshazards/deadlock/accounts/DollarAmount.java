package org.rkoubsky.jcip.part3.livenessperformanceandtesting.chapter10.livenesshazards.deadlock.accounts;

public class DollarAmount implements Comparable<DollarAmount> {
    // Needs implementation

    public DollarAmount(final int amount) {
    }

    public DollarAmount add(final DollarAmount d) {
        return null;
    }

    public DollarAmount subtract(final DollarAmount d) {
        return null;
    }

    @Override
    public int compareTo(final DollarAmount dollarAmount) {
        return 0;
    }
}
