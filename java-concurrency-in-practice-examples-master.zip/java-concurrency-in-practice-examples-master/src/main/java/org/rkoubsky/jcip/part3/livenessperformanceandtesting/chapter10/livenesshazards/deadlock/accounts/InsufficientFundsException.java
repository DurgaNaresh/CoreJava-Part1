package org.rkoubsky.jcip.part3.livenessperformanceandtesting.chapter10.livenesshazards.deadlock.accounts;

public class InsufficientFundsException extends Exception {
}
