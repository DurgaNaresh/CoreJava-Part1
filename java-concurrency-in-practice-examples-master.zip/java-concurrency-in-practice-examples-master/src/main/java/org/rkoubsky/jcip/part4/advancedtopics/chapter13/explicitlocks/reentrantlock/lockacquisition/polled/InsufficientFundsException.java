package org.rkoubsky.jcip.part4.advancedtopics.chapter13.explicitlocks.reentrantlock.lockacquisition.polled;

public class InsufficientFundsException extends Exception {
}
