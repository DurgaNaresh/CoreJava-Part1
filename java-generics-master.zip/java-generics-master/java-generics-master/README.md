**java generics example**

this repo includes java generics topic's code examples

thaks to Richard Warburton