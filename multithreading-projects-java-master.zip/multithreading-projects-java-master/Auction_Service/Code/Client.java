package hw2;

public interface Client extends Runnable
{
	String name();
}