## The Travelling Salesman Problem with Akka in JAVA

## Run with Maven

This sample also includes a Maven pom.xml.

You can run the main classes with `mvn` from a terminal window 
    mvn compile exec:java -Dexec.mainClass="hw.akka.User"

